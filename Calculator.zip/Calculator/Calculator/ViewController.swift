//
//  ViewController.swift
//  Calculator
//
//  Created by Sudheer  Movva on 4/26/16.
//  Copyright © 2016 movva. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var displayLabel: UILabel!
    var isFirstDigit = true
    var operand1:Double = 0
    var operation = "="
    //var middle = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    var displayValue:Double {
        get{
            return NSNumberFormatter().numberFromString(displayLabel.text!)!.doubleValue
        }
        
        set{
            displayLabel.text = "\(newValue)"
            isFirstDigit = true
            operation = "="
            //middle = false
        }
    }
    
    func clearDisplay(){
        displayValue = 0
    }
  
    @IBAction func digitOne(sender: UIButton) {
        
        let digit = sender.currentTitle!
        if isFirstDigit{
                displayLabel.text = digit
        } else {
                displayLabel.text = displayLabel.text!
        }
        isFirstDigit = false
    }

    @IBAction func digitTwo(sender: UIButton) {
        let digit = sender.currentTitle!
        if isFirstDigit{
            displayLabel.text = digit
        } else {
            displayLabel.text = displayLabel.text!
        }
        isFirstDigit = false
    }


    @IBAction func digitThree(sender: UIButton) {
        let digit = sender.currentTitle!
        if isFirstDigit{
            displayLabel.text = digit
        } else {
            displayLabel.text = displayLabel.text!
        }
        isFirstDigit = false
    }



    @IBAction func digitFour(sender: UIButton) {
        let digit = sender.currentTitle!
        if isFirstDigit{
            displayLabel.text = digit
        } else {
            displayLabel.text = displayLabel.text!
        }
        isFirstDigit = false
    }

    

    @IBAction func digitFive(sender: UIButton) {
        let digit = sender.currentTitle!
        if isFirstDigit{
            displayLabel.text = digit
        } else {
            displayLabel.text = displayLabel.text!
        }
        isFirstDigit = false
    }

    @IBAction func digitSix(sender: UIButton) {
        let digit = sender.currentTitle!
        if isFirstDigit{
            displayLabel.text = digit
        } else {
            displayLabel.text = displayLabel.text!
        }
        isFirstDigit = false
    }

    @IBAction func digitSeven(sender: UIButton) {
        let digit = sender.currentTitle!
        if isFirstDigit{
            displayLabel.text = digit
        } else {
            displayLabel.text = displayLabel.text!
        }
        isFirstDigit = false
    }

    @IBAction func digitEight(sender: UIButton) {
        let digit = sender.currentTitle!
        if isFirstDigit{
            displayLabel.text = digit
        } else {
            displayLabel.text = displayLabel.text!
        }
        isFirstDigit = false
    }

    @IBAction func digitNine(sender: UIButton) {
        let digit = sender.currentTitle!
        if isFirstDigit{
            displayLabel.text = digit
        } else {
            displayLabel.text = displayLabel.text!
        }
        isFirstDigit = false
    }

    @IBAction func opPlus(sender: UIButton) {
        
        operation = sender.currentTitle!
        operand1 = displayValue
        isFirstDigit = true
    }

    @IBAction func opMinus(sender: UIButton) {
        operation = sender.currentTitle!
        operand1 = displayValue
        isFirstDigit = true
    }


    @IBAction func opMult(sender: UIButton) {
        operation = sender.currentTitle!
        operand1 = displayValue
        isFirstDigit = true
    }

    @IBAction func opDiv(sender: UIButton) {
        operation = sender.currentTitle!
        operand1 = displayValue
        isFirstDigit = true
    }

    @IBAction func opEqual(sender: UIButton) {
        
        switch operation {
            case "/": displayValue = operand1/displayValue
            case "*": displayValue *= operand1
            case "+": displayValue += operand1
            case "-": displayValue = operand1-displayValue
        default: break
        }
        
    }
    
    @IBAction func onZero(sender: UIButton) {
        let digit = sender.currentTitle!
        if isFirstDigit{
            displayLabel.text = digit
        } else {
            displayLabel.text = displayLabel.text!
        }
        isFirstDigit = false

    }
    
    @IBAction func onClear(sender: UIButton) {
        clearDisplay()
    }

}

