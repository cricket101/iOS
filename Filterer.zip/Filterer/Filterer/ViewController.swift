//
//  ViewController.swift
//  Filterer
//
//  Created by Sudheer  Movva on 4/19/16.
//  Copyright © 2016 Sudheer. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    var filteredImage:UIImage?
    var originalImage:UIImage?
    //var imgView:UIImageView?
    var currentImage:UIImage?
    
    @IBOutlet weak var compareButton: UIButton!
    @IBOutlet weak var imageView: UIImageView!

    @IBOutlet weak var editButton: UIButton!
    
    @IBOutlet var secondaryMenu: UIView!
    
    @IBOutlet weak var filterView: UIImageView!
    
    @IBOutlet weak var filterButton: UIButton!
    @IBOutlet weak var horizontalSlider: UISlider!
    @IBOutlet weak var bottomMenu: UIView!
    
    @IBOutlet weak var overlayTextView: UITextView!

    @IBOutlet weak var overlayView: UIView!

    @IBOutlet weak var redButton: UIButton!
    @IBOutlet weak var greenButton: UIButton!

    @IBOutlet weak var blueButton: UIButton!
/*
    @IBOutlet weak var imageToggle: UIButton!
    @IBAction func onImageToggle(sender: UIButton) {
        if imageToggle.selected{
            let image = UIImage(named:"scenery")!
            imageView.image = image
            imageToggle.selected = false
            
        } else{
        imageView.image = filteredImage
        imageToggle.selected = true
        }
    }
 */
    
    override func viewDidLoad() {
        super.viewDidLoad()
        secondaryMenu.backgroundColor = UIColor.whiteColor().colorWithAlphaComponent(0.5)
        originalImage = imageView.image
        overlayTextView.hidden = false
        compareButton.enabled = false
        //longpress gesture
        let tapGestureRecognizer = UILongPressGestureRecognizer(target:self,action: Selector("toggleImage:"))
        imageView.userInteractionEnabled = true
        imageView.addGestureRecognizer(tapGestureRecognizer)
        
        applyRedFilter()
        applyGreenFilter()
        applyBlueFilter()
        
        editButton.enabled = false
        horizontalSlider.hidden = true
        filterView.hidden = true
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    func toggleImage(sender: UILongPressGestureRecognizer){
        if sender.state == .Began{
            if imageView.image == originalImage {
               imageView.image = filteredImage
                overlayTextView.hidden = true
            } else if imageView.image == filteredImage {
                imageView.image = originalImage
                overlayTextView.hidden = false
            }
        }else if sender.state == .Ended{
            if imageView.image == originalImage {
                imageView.image = filteredImage
                overlayTextView.hidden = true
            } else if imageView.image == filteredImage {
                imageView.image = originalImage
                overlayTextView.hidden = false
            }
        }
    }



    @IBAction func onRedFilter(sender: UIButton) {
        
        redButton.selected = true
        blueButton.selected = true
        greenButton.selected = true
        
        let image = imageView.image!
        let rgbaImage = RGBAImage(image:image)!
        let avgRed = 107
        
        for y in 0..<rgbaImage.height{
            for x in 0..<rgbaImage.width{
                let index = y*rgbaImage.width + x
                var pixel = rgbaImage.pixels[index]
                let redDelta = Int(pixel.red) - avgRed
                var modifier = 1 + 4 * (Double(y) / Double(rgbaImage.height))
                
                if(Int(pixel.red) < avgRed){
                    modifier = 1
                }
                pixel.red = UInt8(max(min(225,Int(round(Double(avgRed) + modifier * Double(redDelta)))),0))
                rgbaImage.pixels[index] = pixel
            }
        }
        
        filteredImage = rgbaImage.toUIImage()
        print("Applying Red Filter")
        imageView.image = filteredImage
        overlayTextView.hidden = true
        compareButton.enabled = true
        editButton.enabled = true
        
        //filterView.hidden = false
        //filterView.image = filteredImage
        //showFilteredImage()

    }
    
    func applyRedFilter(){
        
        let image = self.redButton.currentBackgroundImage
        let rgbaImage = RGBAImage(image:image!)!
        let avgRed = 07
        
        for y in 0..<rgbaImage.height{
            for x in 0..<rgbaImage.width{
                let index = y*rgbaImage.width + x
                var pixel = rgbaImage.pixels[index]
                let redDelta = Int(pixel.red) - avgRed
                var modifier = 1 + 4 * (Double(y) / Double(rgbaImage.height))
                
                if(Int(pixel.red) < avgRed){
                    modifier = 1
                }
                pixel.red = UInt8(max(min(225,Int(round(Double(avgRed) + modifier * Double(redDelta)))),0))
                rgbaImage.pixels[index] = pixel
            }
        }
        
        filteredImage = rgbaImage.toUIImage()
        print("Applying Red Filter to button image")
        self.redButton.setBackgroundImage(filteredImage, forState: .Normal)
        
    }
    
    func applyGreenFilter(){
        
        let image = self.greenButton.currentBackgroundImage
        let rgbaImage = RGBAImage(image:image!)!
        let avgGreen = 07
        
        for y in 0..<rgbaImage.height{
            for x in 0..<rgbaImage.width{
                let index = y*rgbaImage.width + x
                var pixel = rgbaImage.pixels[index]
                let greenDelta = Int(pixel.green) - avgGreen
                var modifier = 1 + 4 * (Double(y) / Double(rgbaImage.height))
                
                if(Int(pixel.green) < avgGreen){
                    modifier = 1
                }
                pixel.green = UInt8(max(min(225,Int(round(Double(avgGreen) + modifier * Double(greenDelta)))),0))
                rgbaImage.pixels[index] = pixel
            }
        }
        
        filteredImage = rgbaImage.toUIImage()
        print("Applying Green Filter to button image")
        self.greenButton.setBackgroundImage(filteredImage, forState: .Normal)
        
    }
    
    func applyBlueFilter(){
        
        let image = self.blueButton.currentBackgroundImage
        let rgbaImage = RGBAImage(image:image!)!
        let avgBlue = 07
        
        for y in 0..<rgbaImage.height{
            for x in 0..<rgbaImage.width{
                let index = y*rgbaImage.width + x
                var pixel = rgbaImage.pixels[index]
                let blueDelta = Int(pixel.blue) - avgBlue
                var modifier = 1 + 4 * (Double(y) / Double(rgbaImage.height))
                
                if(Int(pixel.blue) < avgBlue){
                    modifier = 1
                }
                pixel.blue = UInt8(max(min(225,Int(round(Double(avgBlue) + modifier * Double(blueDelta)))),0))
                rgbaImage.pixels[index] = pixel
            }
        }
        
        filteredImage = rgbaImage.toUIImage()
        print("Applying Blue Filter to button image")
        self.blueButton.setBackgroundImage(filteredImage, forState: .Normal)
        
    }

    
    @IBAction func onGreenFilter(sender: UIButton) {
        
        redButton.selected = false
        blueButton.selected = true
        greenButton.selected = false
        
        
        let image = imageView.image!
        let rgbaImage = RGBAImage(image:image)!
        let avgGreen = 107
        
        for y in 0..<rgbaImage.height{
            for x in 0..<rgbaImage.width{
                let index = y*rgbaImage.width + x
                var pixel = rgbaImage.pixels[index]
                let greenDelta = Int(pixel.green) - avgGreen
                var modifier = 1 + 4 * (Double(y) / Double(rgbaImage.height))
                
                if(Int(pixel.green) < avgGreen){
                    modifier = 1
                }
                pixel.green = UInt8(max(min(225,Int(round(Double(avgGreen) + modifier * Double(greenDelta)))),0))
                rgbaImage.pixels[index] = pixel
            }
        }
        
        filteredImage = rgbaImage.toUIImage()
        print("Applying Green Filter")
        imageView.image = filteredImage
        overlayTextView.hidden = true
        compareButton.enabled = true
        editButton.enabled = true
    }
    
    @IBAction func onBlueFilter(sender: UIButton) {
        
        redButton.selected = false
        blueButton.selected = false
        greenButton.selected = true
        
        
        let image = imageView.image!
        let rgbaImage = RGBAImage(image:image)!
        let avgBlue = 107
        
        for y in 0..<rgbaImage.height{
            for x in 0..<rgbaImage.width{
                let index = y*rgbaImage.width + x
                var pixel = rgbaImage.pixels[index]
                let blueDelta = Int(pixel.blue) - avgBlue
                var modifier = 1 + 4 * (Double(y) / Double(rgbaImage.height))
                
                if(Int(pixel.blue) < avgBlue){
                    modifier = 1
                }
                pixel.blue = UInt8(max(min(225,Int(round(Double(avgBlue) + modifier * Double(blueDelta)))),0))
                rgbaImage.pixels[index] = pixel
            }
        }
        
        filteredImage = rgbaImage.toUIImage()
        print("Applying Blue Filter")
        imageView.image = filteredImage
        overlayTextView.hidden = true
        compareButton.enabled = true
        editButton.enabled = true
    }
    
    
    @IBAction func onCompare(sender: UIButton) {
        
        if (sender.selected) {
            
            print("compare is selected")
            if filteredImage != nil {
                imageView.image = filteredImage
                overlayTextView.hidden = true
            }
            sender.selected = false
            
        } else{
            print("compare is NOT selected")
            imageView.image = originalImage
            overlayTextView.hidden = false
            sender.selected = true
            
            
        }
    }
    
    @IBAction func onShare(sender: UIButton) {
        
        let activityController = UIActivityViewController(activityItems: ["Check out our really cool app", imageView.image!],applicationActivities: nil)
        presentViewController(activityController, animated: true, completion: nil)
    }
    
    @IBAction func onNewPhoto(sender: UIButton) {
        
        let actionSheet = UIAlertController(title: "New Photo", message: nil, preferredStyle: .ActionSheet)
        
        actionSheet.addAction(UIAlertAction(title: "Camera", style: .Default, handler: {
            action in
                self.showCamera()
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Album", style: .Default, handler: {
            action in
                self.showAlbum()
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .Cancel, handler: nil))
        
        self.presentViewController(actionSheet, animated: true, completion: nil)
    }
    
    func showCamera(){
        
        let cameraPicker = UIImagePickerController()
        cameraPicker.delegate = self
        cameraPicker.sourceType = .Camera
        
        presentViewController(cameraPicker, animated: true, completion: nil)
        
    }
    
    func showAlbum(){
        let cameraPicker = UIImagePickerController()
        cameraPicker.delegate = self
        cameraPicker.sourceType = .PhotoLibrary
        
        presentViewController(cameraPicker, animated: true, completion: nil)
        
    }
    
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        dismissViewControllerAnimated(true, completion: nil)
        if let image = info[UIImagePickerControllerOriginalImage] as? UIImage {
        imageView.image = image
        }
    }
    
    func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        dismissViewControllerAnimated(true, completion: nil)
    }

    @IBAction func onFilter(sender: UIButton) {
        
        if (sender.selected) {
            
            hideSecondaryMenu()
            sender.selected = false
            
        } else{
            showSecondaryMenu()
            sender.selected = true
            
        }
        
    }
    
    func showSecondaryMenu() {
        
        view.addSubview(secondaryMenu)
        secondaryMenu.translatesAutoresizingMaskIntoConstraints = false
        
        let bottomConstraint = secondaryMenu.bottomAnchor.constraintEqualToAnchor(bottomMenu.topAnchor)
        let leftConstraint = secondaryMenu.leftAnchor.constraintEqualToAnchor(view.leftAnchor)
        let rightConstraint = secondaryMenu.rightAnchor.constraintEqualToAnchor(view.rightAnchor)
        let heightConstraint = secondaryMenu.heightAnchor.constraintEqualToConstant(44)
        NSLayoutConstraint.activateConstraints([bottomConstraint,leftConstraint,rightConstraint,heightConstraint])
        view.layoutIfNeeded()
        
        //applyRedFilter()
        
        self.secondaryMenu.alpha = 0
        UIView.animateWithDuration(0.4){
        self.secondaryMenu.alpha = 1.0
        }
        
    }
    
    func hideSecondaryMenu(){
        
        UIView.animateWithDuration(0.4, animations: {
            self.secondaryMenu.alpha = 0
        }) { completed in
            if completed == true {
                self.secondaryMenu.removeFromSuperview()
            }
        }
        
    }
    
    func showFilteredImage(){
        view.addSubview(filterView)
        filterView.translatesAutoresizingMaskIntoConstraints=false
        filterView.contentMode = .ScaleAspectFit
        
        let bottomConstraint = filterView.bottomAnchor.constraintEqualToAnchor(imageView.bottomAnchor)
        let leftConstraint = filterView.leftAnchor.constraintEqualToAnchor(imageView.leftAnchor)
        let rightConstraint = filterView.rightAnchor.constraintEqualToAnchor(imageView.rightAnchor)
        let topConstraint = filterView.topAnchor.constraintEqualToAnchor(imageView.topAnchor)
        NSLayoutConstraint.activateConstraints([bottomConstraint, topConstraint, leftConstraint, rightConstraint])
        
        view.layoutIfNeeded()
        showSecondaryMenu()
        filterView.alpha=0
        imageView.alpha = 1.0
        UIView.animateWithDuration(5.0){
            self.imageView.alpha=0
            self.filterView.alpha=1.0
        }
        
    }
    
    @IBAction func onSlide(sender: UISlider) {
        
        let currentImage = imageView.image
        
        let rgbaImage = RGBAImage(image:currentImage!)!
        let sliderValue = sender.value
        horizontalSlider.continuous = true
        print("slider value is " , sliderValue)
   /*
        for y in 0..<rgbaImage.height{
            for x in 0..<rgbaImage.width{
                let index = y*rgbaImage.width + x
                var pixel = rgbaImage.pixels[index]
                let blueDelta = Int(pixel.blue) - avgBlue
                var modifier = 1 + 1 * (Double(sliderValue))
                
                if(Int(pixel.blue) < avgBlue){
                    modifier = 1
                }
                pixel.blue = UInt8(max(min(225,Int(round(Double(avgBlue) + modifier * Double(blueDelta)))),0))
                rgbaImage.pixels[index] = pixel
            }
        }
        
    */
        for y in 0..<rgbaImage.height{
            for x in 0..<rgbaImage.width{
                let index = y*rgbaImage.width + x
                var pixel = rgbaImage.pixels[index]
                
                if redButton.selected{
                    pixel.red = UInt8(sliderValue)
                } else if blueButton.selected {
                    pixel.blue = UInt8(sliderValue)
                }
                    pixel.green = UInt8(sliderValue)
                
                
                    rgbaImage.pixels[index] = pixel
                }
            }
        
        filteredImage = rgbaImage.toUIImage()
        
        if sliderValue == 0{
            imageView.image = currentImage
        }else {
        imageView.image = filteredImage
        }
        
    }
    
    @IBAction func onEditButton(sender: UIButton) {
        hideSecondaryMenu()
        horizontalSlider.hidden = false
    }

}

